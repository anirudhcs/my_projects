#include <set>
using namespace std;

class EquivalenceClass{
    private:
        ValueNumber v;
        ValueExpr ve;
        set<CustomExpr> s;
        
   public:
        
        EquivalenceClass(){
             s.clear();
        }
        
        //Get and set start here..
        
        void setEquivalenceClass(set<CustomExpr> a){
            s = a;     // Need to define the operator = for sets
        }
        set<CustomExpr> getEquivalenceClass(){
            return s;
        }
        ValueNumber getValueNumber(){
            return v;
        }
        ValueExpr getValueExpression(){
            return ve;
        }
        void setValueNumber(ValueNumber a){
            //Just the declaration results in the default "0" ValueNumber.
            ValueNumber t;
            
            v = a;
            if(ve.getOperand1() == t && ve.getOperand2() == t){
                ve.setOperand1(a);
            }
            
        }
        void setValueExpression(ValueExpr a){
            ve = a;
        }
        
        //Get and set start here..
        
        //from here the operator overloading starts..
        
        bool operator==(EquivalenceClass a) const{
            if(v == a.getValueNumber() && ve == a.getValueExpression() && s == a.getEquivalenceClass())   
                return true;
            else
                return false;
        }
        
        bool operator< (EquivalenceClass a) const{
            if(v < a.getValueNumber()){
                return true;
            }
            else
                return false;
        }
        
        bool operator> (EquivalenceClass a) const{
            if(v > a.getValueNumber()){
                return true;
            }
            else
                return false;
        }
        
        void operator=(EquivalenceClass a){
            v = a.getValueNumber();
            ve = a.getValueExpression();
            s = a.getEquivalenceClass();
        }
        

        string printfn(){
            string ret;
            set<CustomExpr>::iterator it;
            CustomExpr c1;
            
            ret = "("+v.printfn()+","+ve.printfn();
            for (it = s.begin(); it != s.end(); ++it){
                c1 = *it;
                ret = ret +","+c1.printfn();
            }
            ret = ret + ")";
            return ret;
            
        }

        string printfn2(){
            string ret;
            set<CustomExpr>::iterator it;
            CustomExpr c1;
            bool first_iteration;
            first_iteration = true;

            ret = "(";
            for (it = s.begin(); it != s.end(); ++it){
                c1 = *it;

                if(first_iteration){
                    ret = ret + c1.printfn();
                    first_iteration = false;
                }
                else{
                    ret = ret +","+c1.printfn();
                }
            }
            ret = ret + ")";
            return ret;
            
        }

        void clearer(){
            s.clear();
            ve.clearer();
            v.clearer();
        }
};
