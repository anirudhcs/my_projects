using namespace std;

class EquivalencesComputed{
	private:
		EquivalenceClass input1, input2, output;

	public:
        //Get and set start here....

        void setInput1(EquivalenceClass c1){
        	input1 = c1;
        }

        void setInput2(EquivalenceClass c1){
        	input2 = c1;
        }

        void setOutput(EquivalenceClass c1){
        	output = c1;
        }

        EquivalenceClass getInput1(){
        	return input1;
        }

        EquivalenceClass getInput2(){
        	return input2;
        }

        EquivalenceClass getOutput(){
        	return output;
        }

        //Get and set end here....


        //Operator overloading fom here........

        bool operator==(EquivalencesComputed a) const{
            if(input1 == a.getInput1() && input2 == a.getInput2() && output == a.getOutput())
                return true;
            else
                return false;
        }
        
        bool operator<(EquivalencesComputed a) const{
            ValueNumber v1,v2;
            EquivalenceClass c1,c2;
            c1 = a.getOutput();
            c2 = output;
            v2 = c2.getValueNumber();
            if(c1.getValueNumber() > v1){
                return true;
            }
            else 
                return false;
        }
        
        bool operator>(EquivalencesComputed a) const{
            ValueNumber v1,v2;
            EquivalenceClass c1,c2;
            c1 = a.getOutput();
            c2 = output;
            v2 = c2.getValueNumber();
            if(c1.getValueNumber() < v1){
                return true;
            }
            else 
                return false;
        }
        void operator=(EquivalencesComputed a){
            input2 = a.getInput2();
            input1 = a.getInput1();
            output = a.getOutput();
        }
        
        std::string printfn(){
            std::string ret;
            ret = "["+input1.printfn()+","+input2.printfn()+","+output.printfn()+"]";
            return ret;
        }

        void clearer(){
            output.clearer();
            input2.clearer();
            input1.clearer();
        }
};
