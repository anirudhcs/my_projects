#include <string>
#include <iostream>
#include "gvn.h"
#include "llvm/Pass.h"
#include "llvm/IR/Value.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/Support/CFG.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Constant.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/Type.h"

#define DEBUG 0

using namespace llvm;

Instruction* curr_Ins;
ConstantInt *ci1;
Type *type_checker;

namespace {
  
  struct CustomPass : public FunctionPass {
    static char ID;
    CustomPass() : FunctionPass(ID) {}
    
    bool runOnFunction(Function &F) {//errs()<<"New Function\n";
        string x,y,str_temp1,str_temp2;
        unsigned op_code;
        bool changes,first_instruction,first_predecessor,first_iteration;
        std::set<InstructionMetaData> pool,pool_cmp;
        std::set<InstructionMetaData>::iterator pool_it,pool_itt;
        std::set<EquivalenceClass>::iterator class_it;
        std::set<EquivalenceClass> class1_set;
        InstructionMetaData m1,m2;
        ExpressionPool e1,e2,e3,eout_prev,empty_pool,cmp1,cmp2;
        EquivalenceClass class1;
        CustomExpr c1;
        Instruction* terminator_instr;
        BasicBlock *parent_block,*pred_block;
        int chang,count_redun,iter_no;
        chang = 0;
        iter_no = 1;
        ValueExpr ve1;
        
        //The Initialization step
        for (Function::iterator b = F.begin(), be = F.end(); b != be; ++b){
            for (BasicBlock::iterator i = b->begin(), ie = b->end(); i != ie; ++i){
                curr_Ins = cast<Instruction>(i);
                m1.setInstruction(curr_Ins);
                pool.insert(m1);
            }
        }
        
        changes = true;
        first_iteration = true;
        
        //The actual interation
        while(changes){//errs()<<"New Iteration"<<iter_no<<"\n\n";
            changes = false;

            for (Function::iterator b = F.begin(), be = F.end(); b != be; ++b){//errs()<<"\n\n\nNew Block\n";
                first_instruction = true;
                e1.clearer();
                e2.clearer();
                for (BasicBlock::iterator i = b->begin(), ie = b->end(); i != ie; ++i){//errs()<<"New Instruction"<<chang<<"\n";chang = chang +1;
                    curr_Ins = cast<Instruction>(i);
                    // errs()<<*curr_Ins<<"\n";
                    
                    //First Compute Ein
                    if(first_instruction){
                        parent_block = curr_Ins->getParent();
                        first_predecessor = true;
                        for (pred_iterator PI = pred_begin(parent_block), E = pred_end(parent_block); PI != E; ++PI){
                            pred_block = *PI;
                            terminator_instr = cast<Instruction>(pred_block->getTerminator());
                            //now search inside the set of instruction-metadata and once it is found use the ein and eout values of that
                            for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                                m2 = *pool_it;
                                if(terminator_instr == m2.getInstruction()){
                                    if(first_predecessor){//errs()<<"Hello444\n";
                                        e1 = m2.getEout();
                                        first_predecessor = false;
                                    }
                                    else{
                                        e2 = m2.getEout();//errs()<<"Algorithm2\n";
                                        e1 = Algorithm2(e1,e2);//errs()<<"Hello555\n";
                                    }
                                    break;
                                }
                            }
                            
                        }
                        first_instruction = false;
                    }
                    else{
                        e1 = eout_prev;
                    }
                    
                    for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                        m2 = *pool_it;
                        if(curr_Ins == m2.getInstruction()){
                            m2.setEin(e1);
                            pool.erase(pool_it);
                            pool.insert(m2);
                            break;
                        }
                    }
                    e1.clearer();
                    e2.clearer();

                    // #if DEBUG == 1
                    // for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                    //     m2 = *pool_it;
                    //     if(curr_Ins == m2.getInstruction()){
                    //         errs()<<"Ei:"<<m2.getEin().printfn()<<"\n";
                    //         break;
                    //     }
                    // }
                    // #endif  

                    //then Compute Eout.... Here is where things get a bit tricky. Need to send info based on the type of the expression
                    //Need to keep track of The "change" variable.......
                    for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                        m2 = *pool_it;
                        if(curr_Ins == m2.getInstruction()){
                            e1 = m2.getEin();//errs()<<"Hello\n";
                            
                            op_code = curr_Ins->getOpcode();
                            type_checker = curr_Ins->getType();
                            if(type_checker->getTypeID() != 10 && op_code != 49 && op_code != 1){
                              op_code = 50;
                            }
                            switch(op_code){
                            case 8  : {x = curr_Ins->getName();
                                       c1.clearer();
                                       c1.setOperator("+");
                                       str_temp1 = curr_Ins->getOperand(0)->getName();
                                       c1.setOperand1(str_temp1);
                                       str_temp2 = curr_Ins->getOperand(1)->getName();
                                       if(str_temp2 == ""){
                                          ci1 = cast<ConstantInt>(curr_Ins->getOperand(1));
                                          str_temp2 = ci1->getValue().toString(10,true);
                                       }
                                       c1.setOperand2(str_temp2);
                                       c1.setBinary(true);//errs()<<"Algorithm1\n";
                                       e2 = Algorithm1(e1,x,c1);
                                       break;} 

                            
                            case 10  : {x = curr_Ins->getName();
                                       c1.clearer();
                                       c1.setOperator("-");
                                       str_temp1 = curr_Ins->getOperand(0)->getName();
                                       c1.setOperand1(str_temp1);
                                       str_temp2 = curr_Ins->getOperand(1)->getName();
                                       if(str_temp2 == ""){
                                          ci1 = cast<ConstantInt>(curr_Ins->getOperand(1));
                                          str_temp2 = ci1->getValue().toString(10,true);
                                       }
                                       c1.setOperand2(str_temp2);
                                       c1.setBinary(true);//errs()<<"Algorithm1\n";
                                       e2 = Algorithm1(e1,x,c1);
                                       break;}

                            case 12  : {x = curr_Ins->getName();
                                       c1.clearer();
                                       c1.setOperator("*");
                                       str_temp1 = curr_Ins->getOperand(0)->getName();
                                       c1.setOperand1(str_temp1);
                                       str_temp2 = curr_Ins->getOperand(1)->getName();
                                       if(str_temp2 == ""){
                                          ci1 = cast<ConstantInt>(curr_Ins->getOperand(1));
                                          str_temp2 = ci1->getValue().toString(10,true);
                                       }
                                       c1.setOperand2(str_temp2);
                                       c1.setBinary(true);//errs()<<"Algorithm1\n";
                                       e2 = Algorithm1(e1,x,c1);
                                       break;}

                            case 15  : {x = curr_Ins->getName();
                                       c1.clearer();
                                       c1.setOperator("/");
                                       str_temp1 = curr_Ins->getOperand(0)->getName();
                                       c1.setOperand1(str_temp1);
                                       str_temp2 = curr_Ins->getOperand(1)->getName();
                                       if(str_temp2 == ""){
                                          ci1 = cast<ConstantInt>(curr_Ins->getOperand(1));
                                          str_temp2 = ci1->getValue().toString(10,true);
                                       }
                                       c1.setOperand2(str_temp2);
                                       c1.setBinary(true);//errs()<<"Algorithm1\n";
                                       e2 = Algorithm1(e1,x,c1);
                                       break;}

                            case 27 : {
                                       x = curr_Ins->getName();
                                       c1.clearer();
                                       c1.setOperator("");
                                       c1.setOperand1(curr_Ins->getOperand(0)->getName());
                                       c1.setVar(true);
                                       // errs()<<"\nInstruction:"<<*curr_Ins<<"\n";
                                       // errs()<<"e1:"<<e1.printfn()<<"\n";
                                       // errs()<<"x:"<<x<<"\n";
                                       // errs()<<"c1:"<<c1.printfn()<<"\n";
                                       //errs()<<"Algorithm1\n";
                                       e2 = Algorithm1(e1,x,c1);
                                       // errs()<<"e2:"<<e2.printfn()<<"\n";
                                       break;}
                            case 28 : {
                                       x = curr_Ins->getOperand(1)->getName();
                                       c1.clearer();
                                       c1.setOperator("");
                                       y = curr_Ins->getOperand(0)->getName();
                                       if(y == ""){//errs()<<"Hello123\t"<<*curr_Ins<<"\n\n\n\n\n\n";
                                          ci1 = cast<ConstantInt>(curr_Ins->getOperand(0));
                                          y = ci1->getValue().toString(10,true);
                                       }
                                       c1.setOperand1(y);
                                       c1.setVar(true);
                                       if(y != ""){
                                           //errs()<<"Algorithm1\n";
                                           e2 = Algorithm1(e1,x,c1);
                                       }
                                       else{
                                           e2 = e1;
                                       }
                                       break;}
                            case 26 : {x = curr_Ins->getName();
                                       if(first_iteration){
                                           //errs()<<"Algorithm5\n";
                                           e2 = Algorithm5(e1,x);
                                           first_iteration = false;    
                                       }
                                       else{
                                          e2 = m2.getEout();
                                       }
                                       break;}

                            case 49 : {e2 = empty_pool;
                                       break;}

                            case 1 : {e2 = empty_pool;
                                       break;}

                            case 2 : {e2 = e1;
                                       break;}

                            default : {
                                          e2 = e1;
                                          break;
                                      }
                            }
                            
                            // e2 = trim2(e2);
                            
                            // if(!(isEqual_ValueInfoDiscarded(e2,m2.getEout()))){
                            //     changes = true;
                            // }
                            eout_prev = e2;     //errs()<<"Hello111\n";
                            break;
                        }
                    }
                    for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                        m2 = *pool_it;
                        if(curr_Ins == m2.getInstruction()){
                            m2.setEout(e2);
                            pool.erase(pool_it);
                            pool.insert(m2);
                            break;
                        }
                    }
          
                    // #if DEBUG == 1
                    // for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
                    //     m2 = *pool_it;
                    //     if(curr_Ins == m2.getInstruction()){
                    //         errs()<<"Eo:"<<m2.getEout().printfn()<<"\n";
                    //         break;
                    //     }
                    // }
                    // #endif
                    //errs()<<"Hello456\n";
                }
            }       
            // errs()<<"Hello789\n";
            setGlobalValu(1);
            for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
              m1 = *pool_it;
              for (pool_itt = pool.begin(); pool_itt != pool.end(); ++pool_itt){
                m2 = *pool_itt;
                if(m1 == m2){
                  cmp1 = m1.getEout();
                  cmp2 = m2.getEout();
                  if(isEqual_ValueInfoDiscarded(cmp1,cmp2)){
                    changes = false;
                  }
                  else{
                    changes = true;
                  }
                  break;
                }
              }
            }
            chang = 0;
            iter_no = iter_no + 1;    
        }
        
        // // this code is to print the expression pools.....
        // for (Function::iterator b = F.begin(), be = F.end(); b != be; ++b){
        //     for (BasicBlock::iterator i = b->begin(), ie = b->end(); i != ie; ++i){
        //         curr_Ins = cast<Instruction>(i);
        //         for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
        //              m2 = *pool_it;
        //              op_code = curr_Ins->getOpcode();
        //              if(curr_Ins == m2.getInstruction()){
        //             { 
                        
        //                 errs()<<"Ei:"<<m2.getEin().printfn()<<"\n";
        //                 errs()<<*m2.getInstruction()<<"\n";
        //                 errs()<<"Eo:"<<m2.getEout().printfn()<<"\n\n\n";}
        //              }            
        //         }
        //     }
        // }

        //the following code is to count the no of redundancies
        count_redun = 0;
        for (pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
            m2 = *pool_it;
            curr_Ins = m2.getInstruction();
            e1 = m2.getEin();
            op_code = curr_Ins->getOpcode();
            if(op_code == 8){
                x = curr_Ins->getName();
                c1.clearer();
                c1.setOperator("+");
                str_temp1 = curr_Ins->getOperand(0)->getName();
                c1.setOperand1(str_temp1);
                str_temp2 = curr_Ins->getOperand(1)->getName();
                c1.setOperand2(str_temp2);
                c1.setBinary(true);
                ve1 = valueExprComputation(c1,e1);
                // errs()<<"\nInstruction:"<<*curr_Ins<<"\n";
                // errs()<<"e1:"<<e1.printfn()<<"\n";
                class1_set = e1.getExpressionPool();
                // errs()<<"ve1:"<<ve1.printfn()<<"\n";
                for (class_it = class1_set.begin(); class_it != class1_set.end(); ++class_it){
                    class1 = *class_it;
                    if(class1.getValueExpression() == ve1){
                        count_redun++;
                        break;
                    }
                }

            }
        }

        errs()<<"No of redundancies:"<<count_redun<<"\n";
        //chang = chang + count_redun;

        return false;
   }
          
};
}

char CustomPass::ID = 0;
static RegisterPass<CustomPass> X("cus", "Custom GVN Pass", false, false);

