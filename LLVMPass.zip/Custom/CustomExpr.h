#include <string>
#include "llvm/Support/raw_ostream.h"
using namespace std;

class CustomExpr{
    private:
        string operand1, operand2, oper;
        bool var, una, bin;
        
    public:
        CustomExpr(){
            operand1 = "";
            operand2 = "";
            oper = "";
            var = false;
            una = false;
            bin = false;
        }
        
        //Get and set start here..
        
        string getOperand1(){
            return operand1;
        }
        void setOperand1(string a){
            operand1 = a;
        }
        string getOperand2(){
            return operand2;
        }
        void setOperand2(string a){
            operand2 = a;
        }
        string getOperator(){
            return oper;
        }
        void setOperator(string a){
            oper = a;
        }
        
        bool isVar(){
            if(var){
                return true;
            }
            else{
                return false;
            }
        }
        void setVar(bool a){
            var = a;
        }
        bool isUnary(){
            if(una){
                return true;
            }
            else{
                return false;
            }
        }
        void setUnary(bool a){
            una = a;
        }
        bool isBinary(){
            if(bin){
                return true;
            }
            else{
                return false;
            }
        }
        void setBinary(bool a){
            bin = a;
        }
        
        //Get and set end here..
        
        //From here the operator overloading starts..
        
        bool operator== (CustomExpr a) const{
            if(operand1 == a.getOperand1() && operand2 == a.getOperand2() && oper == a.getOperator() && var == a.isVar() && una == a.isUnary() && bin == a.isBinary())
                return true;
            else
                return false;
        } 
        
        bool operator!= (CustomExpr a) const{
            if(operand1 == a.getOperand1() && operand2 == a.getOperand2() && oper == a.getOperator() && var == a.isVar() && una == a.isUnary() && bin == a.isBinary())
                 return false;
             else
                 return true;
        }
        
        bool operator<(CustomExpr a) const{
            if(a.getOperand1() >= operand1){
                if(a.getOperand1() == operand1){
                    if(a.getOperand2() >= operand2){
                        if(a.getOperand2() == operand2){
                            return false;
                        }
                        else{
                            return true;
                        }
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return true;
                }
            }
            else{
                return false;
            }
        }

           
        void operator= (CustomExpr a){
            oper = a.getOperator();
            operand1 = a.getOperand1();
            operand2 = a.getOperand2();
            var = a.isVar();
            una = a.isUnary();
            bin = a.isBinary();
        }
        
        string printfn(){
            string ret;
            if(bin){
                ret = operand1 + oper + operand2;
                return ret;
            }
            else{
                if(una){
                    ret = oper + operand1;
                    return ret;
                }
                else{
                    return operand1;
                }
            }
        }

        void clearer(){
            operand1 = "";
            operand2 = "";
            oper = "";
            var = false;
            una = false;
            bin = false;
        }
};
