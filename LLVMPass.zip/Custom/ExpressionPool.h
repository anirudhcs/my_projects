#include <set>
#include "llvm/Support/raw_ostream.h"

using namespace std;
 
class ExpressionPool{
    private:
        set<EquivalenceClass> s;
        
    public:
        
        ExpressionPool(){
            s.clear();
        }
        //Get and set satart here..
        
        void setExpressionPool(set<EquivalenceClass> a){
            s = a;
        }
        set<EquivalenceClass> getExpressionPool(){
            return s;
        }
        
        //Get and set end here..
        
        //from here the overeloading of the opraotrs starts..
        
        bool operator==(ExpressionPool a) const{
            if(s == a.getExpressionPool())    //need to define the == for sets
                return true;
            else
                return false;
        }
        
        void operator=(ExpressionPool a){
            s = a.getExpressionPool();            //need to define the = for sets
        }
        

        string printfn(){
            string ret;
            set<EquivalenceClass>::iterator it;
            EquivalenceClass c1;
            bool first;
            first = true;
            ret = "{";
            
            for (it = s.begin(); it != s.end(); ++it){
                c1 = *it;
                if(first){
                    ret = ret + c1.printfn();
                    first = false;
                }
                else{
                    ret = ret + "," + c1.printfn();
                }
            }
            ret = ret + "}";
            return ret;
        }

        string printfn2(){
            string ret;
            set<EquivalenceClass>::iterator it;
            EquivalenceClass c1;
            bool first;
            first = true;
            ret = "{";
            
            for (it = s.begin(); it != s.end(); ++it){
                c1 = *it;
                if(first){
                    ret = ret + c1.printfn2();
                    first = false;
                }
                else{
                    ret = ret + "," + c1.printfn2();
                }
            }
            ret = ret + "}";
            return ret;
        }

        void clearer(){
            s.clear();
        }
};
