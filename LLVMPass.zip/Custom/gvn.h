#include <iostream>
#include <string>
#include <set>
#include <algorithm>
#include "ValueNumber.h" 
#include "ValueExpr.h"
#include "CustomExpr.h"
#include "EquivalenceClass.h"
#include "ExpressionPool.h"
#include "InstructionToPoolMap.h"
#include "EquivalencesComputed.h"
#include "llvm/Support/raw_ostream.h"


using namespace std;

int GlobalValu = 1;
set<EquivalencesComputed> finalised;

EquivalenceClass Algorithm3(EquivalenceClass c1, EquivalenceClass c2, ExpressionPool e1, ExpressionPool e2);
ExpressionPool Algorithm2(ExpressionPool e1,ExpressionPool e2);
ExpressionPool Algorithm1(ExpressionPool ein, string x, CustomExpr e);
ExpressionPool Algorithm5(ExpressionPool ein, string x);
ValueExpr valueExprComputation(CustomExpr e, ExpressionPool);
ValueExpr valueNumberComputation2(CustomExpr c1, ExpressionPool ein);
ValueNumber valueNumberComputation(CustomExpr c1, ExpressionPool ein);
ExpressionPool trim2(ExpressionPool e2);
int getGlobalValu();
void setGlobalValu(int a);
int getNewGlobalValue(ExpressionPool e1);
int getNewGlobalValue2(ExpressionPool e1, ExpressionPool e2);
void printer(CustomExpr);
void printer(ValueNumber);
void printer(ValueExpr);
void printer(EquivalenceClass);
void printer(EquivalencesComputed);
void printer(ExpressionPool);
void printer(set<InstructionMetaData> a);
string printer2(set<InstructionMetaData> a);
void printer(string s);
void printer(Instruction *ins);
bool isEqual_ValueInfoDiscarded(ExpressionPool a, ExpressionPool b);

void printer(Instruction *ins){
  errs()<<*ins<<"\n";
}

void printer(string s){
  errs()<<s<<"\n";
}

bool isEqual_ValueInfoDiscarded(ExpressionPool a, ExpressionPool b){
    string a1,a2;
    bool ret;
    a1 = a.printfn2();
    a2 = b.printfn2();
    if(a1 == a2){
        ret = true;
    }
    else{
        ret = false;
    }
    return ret;
}

void printer(ValueNumber a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

void printer(set<InstructionMetaData> a){
    InstructionMetaData i;
    bool first_iteration;
    first_iteration = true;
    errs()<<"{";
    for(set<InstructionMetaData>::iterator it = a.begin(); it != a.end(); it++){
        if(first_iteration){
          first_iteration = false;
        }
        else{
          errs()<<",";
        }
        i = *it;
        errs()<<"["<<*i.getInstruction()<<";"<<i.getEin().printfn2()<<","<<i.getEout().printfn2()<<"]";
    }
    errs()<<"}\n";

}

// string printer2(set<InstructionMetaData> a){
//     InstructionMetaData i;
//     bool first_iteration;
//     first_iteration = true;
//     string ret;

//     ret = "{";
//     for(set<InstructionMetaData>::iterator it = a.begin(); it != a.end(); it++){
//         if(first_iteration){
//           first_iteration = false;
//         }
//         else{
//           ret = ret + ",";
//         }
//         i = *it;
//         ret = ret + "[" + *i.getInstruction() + ";" + i.getEin().printfn2() + "," + i.getEout().printfn2() + "]";
//     }
//     ret = ret + "}\n";

//     return ret;

// }

void printer(ExpressionPool a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

void printer(EquivalencesComputed a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

void printer(CustomExpr a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

void printer(ValueExpr a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

void printer(EquivalenceClass a){
  string ret;
  ret = a.printfn();
  errs()<<ret<<"\n";
}

EquivalenceClass Algorithm3(EquivalenceClass ci, EquivalenceClass cj, ExpressionPool e1, ExpressionPool e2){
  // cout<<"ci = "<<ci.printfn()<<"\n";
  // cout<<"cj = "<<cj.printfn()<<"\n";
  int newValueNumber;
  set<CustomExpr> c_k,ct,s1,s2;
  set<EquivalenceClass> ec1;
  EquivalenceClass ck,ck1,ck2,ci1,ci2,cj1,cj2,temp,empty_class,test1,test2;
  bool fi1,fi2,fj1,fj2,isComputed1;
  ValueNumber v,v2,v3,v4;
  ValueExpr ve,ve1,ve2,ve3;
  EquivalencesComputed equi_comp,equi_comp1;

  // for(set<EquivalencesComputed>::iterator itt = finalised.begin(); itt != finalised.end(); itt++){
  //     equi_comp1 = *itt;
  //     cout<<equi_comp1.printfn()<<",";
  // }
  c_k.clear();
  s1 = ci.getEquivalenceClass();
  s2 = cj.getEquivalenceClass();
  
  set_intersection(s1.begin(), s1.end(),s2.begin(), s2.end(),inserter(ct, ct.end()));
  
  if(!ct.empty()){
      for(set<CustomExpr>::iterator it = ct.begin(); it != ct.end(); it++){
           c_k.insert(*it);
      }
  }
  
  
  ve2 = ci.getValueExpression();
  v3 = ve2.getOperand2();
  ve3 = cj.getValueExpression();
  v4 = ve3.getOperand2();

  if(!(v3 == v) || !(v4 == v)){
      if((ve2.getOperator() == ve3.getOperator())){
          
          //to assign ci1
          ve1 = ci.getValueExpression();
          v2 = ve1.getOperand1();
          if(!(v2 == v)){
              fi1 = true;
              ec1 = e1.getExpressionPool();
              for(set<EquivalenceClass>::iterator it = ec1.begin(); it != ec1.end(); it++){
                  temp = *it;
                  if(temp.getValueNumber() == ci.getValueExpression().getOperand1()){
                      ci1 = *it;
                      break;
                  }
              }
              ec1.clear();
          }
          else
              fi1 = false;
          
          
          //to assign ci2
          ve1 = ci.getValueExpression();
          v2 = ve1.getOperand2();
          if(!(v2 == v)){
              fi2 = true;
              ec1 = e1.getExpressionPool();
              for(set<EquivalenceClass>::iterator it = ec1.begin(); it != ec1.end(); it++){
                  temp = *it;
                  if(temp.getValueNumber() == ci.getValueExpression().getOperand2()){
                      ci2 = *it;
                      break;
                  }
              }
              ec1.clear();
          }
          else
              fi2 = false;
          
          
          //to assign cj1
          ve1 = cj.getValueExpression();
          v2 = ve1.getOperand1();
          if(!(v2 == v)){
              fj1 = true;
              ec1 = e2.getExpressionPool();
              for(set<EquivalenceClass>::iterator it = ec1.begin(); it != ec1.end(); it++){
                  temp = *it;
                  if(temp.getValueNumber() == cj.getValueExpression().getOperand1()){
                      cj1 = *it;
                      break;
                  }
              }
              ec1.clear();
          }
          else
              fj1 = false;
          
          
          //to assign cj2
          ve1 = cj.getValueExpression();
          v2 = ve1.getOperand2();
          if(!(v2 == v)){
              fj2 = true;
              ec1 = e2.getExpressionPool();
              for(set<EquivalenceClass>::iterator it = ec1.begin(); it != ec1.end(); it++){
                  temp = *it;
                  if(temp.getValueNumber() == cj.getValueExpression().getOperand2()){
                      cj2 = *it;
                      break;
                  }
              }
              ec1.clear();
          }
          else
              fj2 = false;
              
          
          
          // the computation of ck1
          if(fi1 == true){
              isComputed1 = false;
              if(fj1 == true){
                  // cout<<"Inside ck1 computation:\n";
                  for(set<EquivalencesComputed>::iterator itt = finalised.begin(); itt != finalised.end(); itt++){
                      equi_comp1 = *itt;
                      // cout<<equi_comp1.printfn()<<",";
                      test1 = equi_comp1.getInput1();
                      test2 = equi_comp1.getInput2();
                      if((ci1 == test1 && cj1 == test2) || (cj1 == test1 && ci1 == test2)){
                            isComputed1 = true;
                            ck1 = equi_comp1.getOutput();
                      }
                  }
                  if(!isComputed1){
                      ck1 = Algorithm3(ci1,cj1,e1,e2);
                      equi_comp.setInput1(ci1);
                      equi_comp.setInput2(cj1);
                      equi_comp.setOutput(ck1);
                      if(!(ck1.getValueNumber() == v))
                          finalised.insert(equi_comp);
                      equi_comp.clearer();
                  }
                  equi_comp.clearer();
              }
              else{
                  ck1 = ci1;
              }
          }
          else{
             if(fj1 == true){
                 ck1 = cj1;
             }
             else{
                  ck1 = empty_class;
             }
          }
          
          // the computation of ck2
          if(fi2 == true){
              isComputed1 = false;
              if(fj2 == true){
                  // cout<<"Inside ck2 computation:\n";
                  for(set<EquivalencesComputed>::iterator itt = finalised.begin(); itt != finalised.end(); itt++){
                      equi_comp1 = *itt;
                      // cout<<equi_comp1.printfn()<<",";
                      test1 = equi_comp1.getInput1();
                      test2 = equi_comp1.getInput2();
                      if((ci2 == test1 && cj2 == test2) || (cj2 == test1 && ci2 == test2)){
                            isComputed1 = true;
                            ck2 = equi_comp1.getOutput();
                      }
                  }
                  if(!isComputed1){
                      ck2 = Algorithm3(ci2,cj2,e1,e2);
                      equi_comp.setInput1(ci2);
                      equi_comp.setInput2(cj2);
                      equi_comp.setOutput(ck2);
                      if(!(ck2.getValueNumber() == v))
                          finalised.insert(equi_comp);
                      equi_comp.clearer();
                  }
                  equi_comp.clearer();
              }
              else{
                  ck2 = ci2;
              }
          }
          else{
              if(fj2 == true){
                ck2 = cj2;
              }
              else{
                ck2 = empty_class;
              }
          }
          
          if(!(ck1.getEquivalenceClass().empty()) && !(ck2.getEquivalenceClass().empty())){
              ve.setOperand1(ck1.getValueNumber());
              ve.setOperand2(ck2.getValueNumber());
              ve.setOperator(ci.getValueExpression().getOperator());
              ck.setValueExpression(ve);
          }
      }
  } 
   
   ck.setEquivalenceClass(c_k);
   if(!(c_k.empty()) || (!(ck.getValueExpression().getOperand1() == v) && !(ck.getValueExpression().getOperand2() == v))){
       newValueNumber = getNewGlobalValue2(e1,e2);
       v.setValueNumber(newValueNumber);
       ck.setValueNumber(v);
   }
  // cout<<"ck = "<<ck.printfn()<<"\n\n\n";
  return ck;

}


ExpressionPool Algorithm2(ExpressionPool e1, ExpressionPool e2){
    ExpressionPool ek;
    EquivalenceClass ck,ck1,ck2,test1,test2;
    set<EquivalenceClass> temp,temp1;
    set<CustomExpr> t2;
    set<EquivalenceClass> t1;
    EquivalencesComputed equi_comp,equi_comp1;
    ValueExpr empty_class;
    ek.getExpressionPool().clear();
    temp1 = e1.getExpressionPool();
    bool isComputed;
    ValueNumber zero_number;
    

    isComputed = false;
    //errs()<<"e1"<<e1.printfn()<<"\n";
    // errs()<<"e2"<<e2.printfn()<<"\n";
    
    for(set<EquivalenceClass>::iterator it=temp1.begin(); it != temp1.end(); it++){
        temp = e2.getExpressionPool();
        for(set<EquivalenceClass>::iterator ti = temp.begin(); ti != temp.end(); ti++){
            ck1 = *it;
            ck2 = *ti;
            //Check in finalised to see ifit is alredy present...... else compute.....
            for(set<EquivalencesComputed>::iterator itt = finalised.begin(); itt != finalised.end(); itt++){
                equi_comp1 = *itt;
                test1 = equi_comp1.getInput1();
                test2 = equi_comp1.getInput2();
                if((ck1 == test1 && ck2 == test2) || (ck2 == test1 && ck1 == test2)){
                      isComputed = true;
                      ck = equi_comp1.getOutput();
                }
            }
            
            if(!isComputed){
                ck = Algorithm3(ck1,ck2,e1,e2);
                equi_comp.setInput1(ck1);
                equi_comp.setInput2(ck2);
                equi_comp.setOutput(ck);
                if(!(ck.getValueNumber() == zero_number)){
                    finalised.insert(equi_comp);
                } 
                equi_comp.clearer();
            }
            if(!(ck.getEquivalenceClass().empty() && ck.getValueExpression() == empty_class)){
                //possibility of an error....................................................
                t1 = ek.getExpressionPool();
                t1.insert(ck);
                ek.setExpressionPool(t1);
            }
        }
    }
    
    return ek;
}



ExpressionPool Algorithm1(ExpressionPool ein, string x, CustomExpr e){
    int newValueNumber;
    ExpressionPool et;
    EquivalenceClass c1,c_remove_purpose,c_new_addition,c_temp,c_temp2;
    CustomExpr com,expr_temp,expr_temp2;
    ValueExpr ve1,ve_temp,ve_temp2;
    bool rem,addi;
    ValueNumber newValue;
    set<CustomExpr> t2,eqClass_temp;
    set<EquivalenceClass> t1,expPool_temp;
    
    rem = false;
    addi = false;
    com.setOperand1(x);
    com.setVar(true);
    et = ein;
    //Need to remove.................
    // errs()<<"Inside Algorithm1\n"<<"x:"<<x<<"\t"<<"e:"<<e.printfn()<<"\n"<<"ein:"<<ein.printfn()<<"\n";


    ve1 = valueExprComputation(e,ein);
    // //Need to remove.................
    // errs()<<"The computed Value of ValueExpr:"<<ve1.printfn()<<"\n";
    
    //Removing x from any occurence inside the pool
    expPool_temp = et.getExpressionPool();
    c1.clearer();
    for(set<EquivalenceClass>::iterator it = expPool_temp.begin(); it != expPool_temp.end(); it++){
        c1 = *it;
        eqClass_temp = c1.getEquivalenceClass();
        for(set<CustomExpr>::iterator ti = eqClass_temp.begin(); ti != eqClass_temp.end(); ti++){
            expr_temp = *ti; 
            if(com == expr_temp){
                //possibility of an error.................................
                c_temp2 = c1;
                t2 = c1.getEquivalenceClass();
                for(set<CustomExpr>::iterator tii = t2.begin(); tii != t2.end(); tii++){
                    expr_temp2 = *tii;
                    if(com == expr_temp2){
                        t2.erase(tii);
                        break;
                    }
                }    
                c_temp2.setEquivalenceClass(t2);
                t1 = et.getExpressionPool();
                for(set<EquivalenceClass>::iterator itt = t1.begin(); itt != t1.end(); itt++){
                    c_temp = *itt;
                    if(c1 == c_temp){
                        t1.erase(itt);
                        break;
                    }
                }
                   
                t1.insert(c_temp2);
                et.setExpressionPool(t1);               
                rem = true;
                break;
            }
        }
        if(rem == true){
            break;
        }
    }
    // errs()<<"the value of et after step1:"<<et.printfn()<<"\n";
    c1.clearer();
    expPool_temp = et.getExpressionPool();
    
    //Searcing from the existence of anyy class with the same valu expression
    for(set<EquivalenceClass>::iterator it = expPool_temp.begin(); it != expPool_temp.end(); it++){
        c1 = *it;  
        // errs()<<"The value of c1:"<<c1.printfn()<<"\n";
        ve_temp = c1.getValueExpression();
        if(ve_temp == ve1){
          // errs()<<"the value of ve_temp:"<<ve_temp.printfn()<<"\n";
            //possibility of an error........................
            t2 = c1.getEquivalenceClass();
            t2.insert(com);
            c1.setEquivalenceClass(t2);
            t1 = et.getExpressionPool();
            for(set<EquivalenceClass>::iterator itt = t1.begin(); itt != t1.end(); itt++){
                c_remove_purpose = *itt;
                ve_temp2 = c_remove_purpose.getValueExpression();
                if(ve_temp2 == ve1){
                    t1.erase(itt);
                    break;
                }
            }    
            if(!e.isBinary()){  
              t1.insert(c1);
              et.setExpressionPool(t1);
            }
            addi = true;
            break;
        }
    }
    // errs()<<"the value of et after step2:"<<et.printfn()<<"\n";
    if(!addi){
        
        c_new_addition.setValueExpression(ve1);
        newValueNumber = getNewGlobalValue(ein);
        newValue.setValueNumber(newValueNumber);
        //Possibility of an error.......................
        c_new_addition.setValueNumber(newValue);
        t2 = c_new_addition.getEquivalenceClass();
        t2.insert(com);
        if(!e.isBinary()){
          t2.insert(e);
        }
        c_new_addition.setEquivalenceClass(t2);
        t1 = et.getExpressionPool();
        t1.insert(c_new_addition);
        et.setExpressionPool(t1);
        // errs()<<et.printfn()<<"Please Wait\n\n\n\n\n\n\n\n\n\n";
    }  
    // // errs()<<"the value of et after step3:"<<et.printfn()<<"\n";

    return et;
}

ExpressionPool Algorithm5(ExpressionPool ein, string x){
    int newValueNumber;
    CustomExpr com;
    ValueNumber newValue;
    EquivalenceClass c1;
    ValueExpr ve1;
    set<CustomExpr> t;
    set<EquivalenceClass> t1;
    
    com.setOperand1(x);
    com.setVar(true);
    newValueNumber = getNewGlobalValue(ein);
    newValue.setValueNumber(newValueNumber);   
    ve1.setOperand1(newValue);
    c1.setValueExpression(ve1);
    
    //Possibility of an error.......................
    c1.setValueNumber(newValue);
    t = c1.getEquivalenceClass();
    t.insert(com);
    c1.setEquivalenceClass(t);
    t1 = ein.getExpressionPool();
    t1.insert(c1);
    ein.setExpressionPool(t1);
    
    return ein;
    
}

ValueExpr valueExprComputation(CustomExpr e, ExpressionPool ein){
    ValueExpr ret;
    string a1,a2,a3;
    ValueNumber v1,v2;
    CustomExpr c1,c2;
    bool isComp;

    a1 = e.getOperand1();
    a2 = e.getOperand2();
    a3 = e.getOperator();
    c1.setVar(true);
    c1.setOperand1(a1);
    c2.setVar(true);
    c2.setOperand1(a2);
    isComp = e.isBinary();
    if(isComp){
        v1 = valueNumberComputation(c1,ein);
        v2 = valueNumberComputation(c2,ein);

        ret.setOperand1(v1);
        ret.setOperand2(v2);
        ret.setOperator(a3);
    }
    else{
      ret = valueNumberComputation2(c1,ein);
    }
    return ret;
}

ValueNumber valueNumberComputation(CustomExpr c1, ExpressionPool ein){
    set<EquivalenceClass> e_class;
    set<CustomExpr> set_exprs;
    ValueNumber v1;
    bool found;
    EquivalenceClass m2;
    CustomExpr c2,c3;

    found = false;

    e_class = ein.getExpressionPool();
    for(set<EquivalenceClass>::iterator pool_it = e_class.begin(); pool_it != e_class.end(); ++pool_it){
        m2 = *pool_it;
        set_exprs = m2.getEquivalenceClass();
        for(set<CustomExpr>::iterator iter= set_exprs.begin(); iter != set_exprs.end(); ++iter){
            c3 = *iter;
            if(c1 == c3){
                v1 = m2.getValueNumber();
                found = true;
                break;
            }
        }
        if(found){
            break;
        }
    }

    return v1;
}

ValueExpr valueNumberComputation2(CustomExpr c1, ExpressionPool ein){
    set<EquivalenceClass> e_class;
    set<CustomExpr> set_exprs;
    ValueExpr v1;
    bool found;
    EquivalenceClass m2;
    CustomExpr c2,c3;

    found = false;

    e_class = ein.getExpressionPool();
    for(set<EquivalenceClass>::iterator pool_it = e_class.begin(); pool_it != e_class.end(); ++pool_it){
        m2 = *pool_it;
        set_exprs = m2.getEquivalenceClass();
        for(set<CustomExpr>::iterator iter= set_exprs.begin(); iter != set_exprs.end(); ++iter){
            c3 = *iter;
            if(c1 == c3){
                v1 = m2.getValueExpression();
                found = true;
                break;
            }
        }
        if(found){
            break;
        }
    }

    return v1;
}

ExpressionPool trim2(ExpressionPool e2){
    EquivalenceClass m2,m3;
    set<CustomExpr> set_exprs,set_exprs2;
    set<EquivalenceClass> t1,t2;

    t1 = e2.getExpressionPool();
    t2 = e2.getExpressionPool();
    for(set<EquivalenceClass>::iterator pool_it = t1.begin(); pool_it != t1.end(); ++pool_it){
      m2 = *pool_it;
      set_exprs = m2.getEquivalenceClass();
      if(set_exprs.empty()){
          
          for(set<EquivalenceClass>::iterator pool_itt = t2.begin(); pool_itt != t2.end(); ++pool_itt){
              m3 = *pool_itt;
              if(m2 == m3){
                  t2.erase(pool_itt);
                  break;
              }
          }
      } 
    }
    e2.setExpressionPool(t2);
    return e2;
}

int getGlobalValu(){
    return GlobalValu;
}

void setGlobalValu(int a){
    GlobalValu = a;
}

int getNewGlobalValue(ExpressionPool e1){
    int r,i;
    set<EquivalenceClass> pool;
    EquivalenceClass m2;
    ValueNumber v1;
    pool = e1.getExpressionPool();
    r = GlobalValu;
    GlobalValu++;

    for (set<EquivalenceClass>::iterator pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
        m2 = *pool_it;
        v1 = m2.getValueNumber();
        i = v1.getValueNumber();
        if(r == i){
            r = GlobalValu;
            GlobalValu++;
        }
    }
    // errs()<<"The pool in here:"<<e1.printfn()<<"\n"<<"The value number from here:"<<r<<"\n\n";
    return r;
}

int getNewGlobalValue2(ExpressionPool e1, ExpressionPool e2){
    int r,i;
    set<EquivalenceClass> pool;
    EquivalenceClass m2;
    ValueNumber v1;
    pool = e1.getExpressionPool();
    r = GlobalValu;
    GlobalValu++;

    for (set<EquivalenceClass>::iterator pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
        m2 = *pool_it;
        v1 = m2.getValueNumber();
        i = v1.getValueNumber();
        if(r == i){
            r = GlobalValu;
            GlobalValu++;
        }
    }

    pool = e2.getExpressionPool();

    for (set<EquivalenceClass>::iterator pool_it = pool.begin(); pool_it != pool.end(); ++pool_it){
        m2 = *pool_it;
        v1 = m2.getValueNumber();
        i = v1.getValueNumber();
        if(r == i){
            r = GlobalValu;
            GlobalValu++;
        }
    }

    return r;
}
