#include "llvm/IR/Instruction.h"
using namespace llvm;

class InstructionMetaData{
    private:
        Instruction* I;
        ExpressionPool ein,eout;
        
    public:
        
        //Get and set start here..
        
        void setInstruction(Instruction* J){
           I = J;
        }
        
        void setEin(ExpressionPool a){
           ein = a;
        }
        
        void setEout(ExpressionPool a){
           eout = a;
        }
        
        Instruction* getInstruction(){
           return I;
        }
        
        ExpressionPool getEin(){
           return ein;
        }
        
        ExpressionPool getEout(){
           return eout;
        }
        
        //Get and set end here..
        
        //From here the operator overloading starts..
        bool operator== (InstructionMetaData a) const{
            if(I == a.getInstruction() && ein == a.getEin() && eout == a.getEout()){
                return true;
            }
            else{
                return false;
            }
        }
        
        bool operator> (InstructionMetaData a) const{
            if(I>a.getInstruction()){
                return true;
            }
            else
                return false;
        }
        
        bool operator< (InstructionMetaData a) const{
            if(I<a.getInstruction()){
                return true;
            }
            else
                return false;
        }
        
        void operator= (InstructionMetaData a){
            I = a.getInstruction();
            ein = a.getEin();
            eout = a.getEout();
        }
        
        
};
