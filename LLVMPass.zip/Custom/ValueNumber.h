#include <string>
#include <sstream>

class ValueNumber{
    private:
        int v;
    public:
        ValueNumber(){
            v = 0;
        }
        
        // Get and set start here..
        
        void setValueNumber(int a){
            v = a;
        }
        int getValueNumber(){
            return v;
        }
        
        //Get and set end here..
        
        //From here the overloading of the operators..
        
        bool operator==(ValueNumber a) const{
            if(v == a.getValueNumber())
                return true;
            else
                return false;
        }
        
        bool operator<(ValueNumber a) const{
            if(a.getValueNumber() > v){
                return true;
            }
            else 
                return false;
        }
        
        bool operator>(ValueNumber a) const{
            if(a.getValueNumber() < v){
                return true;
            }
            else 
                return false;
        }
        void operator=(ValueNumber a){
            v = a.getValueNumber();
        }
        
        std::string printfn(){
            std::string ret,b;
            std::stringstream a; 
            a<<v;
            b = a.str();
            ret = "v" + b;
            return ret;
        }

        void clearer(){
            v = 0;
        }
};
