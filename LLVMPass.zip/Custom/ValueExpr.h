#include <string>
using namespace std;

class ValueExpr{
    private:
        ValueNumber v1,v2;
        string op;
    public:
       ValueExpr(){
            op = "";
       }
       
       //Get and set start here..
       
       ValueNumber getOperand1(){
           return v1;
       }
       ValueNumber getOperand2(){
           return v2;
       }
       string getOperator(){
           return op;
       }
       void setOperand1(ValueNumber a){
           v1 = a;
       }
       void setOperand2(ValueNumber a){
           v2 = a;
       }
       void setOperator(string a){
           op = a;
       }
       
       //Get and set end here..
       
       //From here the overloading of the operators starts..
       
       bool operator== (ValueExpr a) const{
            if(v1 == a.getOperand1() && v2 == a.getOperand2() && op == a.getOperator())
                return true;
            else
                return false;
        }
        
        
        void operator=(ValueExpr a){
            op = a.getOperator();
            v1 = a.getOperand1();
            v2 = a.getOperand2();
        }
        
        string printfn(){
            std::string ret;
            ValueNumber a;
            if(v2 == a){
            ret = v1.printfn();
            }
            else
            ret = v1.printfn() + op + v2.printfn();
            return ret;
        }

        void clearer(){
            op = "";
            v1.clearer();
            v2.clearer();
        }
       
};
